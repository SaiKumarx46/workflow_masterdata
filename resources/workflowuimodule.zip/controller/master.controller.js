sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("workflowuimodule.controller.master",{onInit:function(){}})});
//# sourceMappingURL=master.controller.js.map